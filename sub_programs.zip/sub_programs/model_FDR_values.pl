#!usr/bin/perl
#model P-value
use warnings;

$name = $ARGV[0]; #print "exp_name is $name\n";
$rep_no = $ARGV[1];  #print "replicate is $rep_no\n";
$chrom = $ARGV[2];  #print "chrom is $chrom\n";

#$name = "epith_test2"; print "exp_name is $name\n";
#$rep_no = "1";  print "replicate is $rep_no\n";
#$chrom = "2L";  print "chrom is $chrom\n";

#print "\nModelling FDR values for replicate $rep_no\n";


open INPUT, 'POLII_analysis_for_'."$name".'/logfiles/chr'."$chrom".'_data_rep'."$rep_no".'_random_data.txt';
@FDR_data = <INPUT>;
$FDR_num = @FDR_data;

$max_gene_size  = 2750;
$bp = 250;

while($bp < $max_gene_size){
	
	$ln = 0;
	while($ln < $FDR_num){
		@col = split(/\t/,$FDR_data[$ln]);
		
		if($bp == $col[2]){push (@thres_values, $col[1]); push (@FDR_values, $col[3]); }
		
		$ln = $ln + 1;
	}
	$array_num = @thres_values;

$iter = 0;	
while($iter < 100000){
$diff_total = 0;
$a = rand(2);
$b = rand(20) + 2;

$ln2 = 0;
while($ln2 < $array_num){
	$predict_FDR = $a * exp(-$b*$thres_values[$ln2]);
	$diff = abs ($FDR_values[$ln2] - $predict_FDR);
	$diff_total = $diff_total + $diff;
	$ln2 = $ln2 + 1;
}

push (@diff_array, "$a\t$b\t$diff_total");

#open LOG, '>> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\chr'."$chrom".'_'."$probe".'probes_curvefit_iterations.txt';
#print LOG "$a\t$b\t$diff_total\n"; #print "$a\t$b\t$diff_total\n";
#close LOG;

$iter = $iter + 1;
} 
$diff_num = @diff_array;
$ln3 = 0;

while($ln3 < $diff_num){
	my @col2 = split(/\t/,$diff_array[$ln3]);
	push @AoA, \@col2;
	$ln3 = $ln3 + 1;	    
	 		}
@sorted_array = sort{$$a[2]<=>$$b[2]}@AoA;

$variable1 = $sorted_array[0][0];
$variable2 = $sorted_array[0][1];

open LOG, '>> POLII_analysis_for_'."$name".'/logfiles/chr'."$chrom".'_data_rep'."$rep_no".'_variables.txt';
print LOG "$chrom\t$bp\t$variable1\t$variable2\n"; #print "$chrom\t$probe\t$variable1\t$variable2\n";
close LOG;

@thres_values = ();
@FDR_values = ();
@diff_array = ();
@AoA = ();
@sorted_array = ();

$bp = $bp + 250;
}
close INPUT;
@FDR_data = ();
#print "\ncurve fit done!\n";