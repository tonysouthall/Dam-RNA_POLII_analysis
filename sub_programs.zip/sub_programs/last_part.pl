#!usr/bin/perl
#calculate P-value
use warnings;

#$name = $ARGV[0]; print "exp_name is $name\n";
#$chrom = $ARGV[1];  print "chrom is $chrom\n";

$exp_name = "epith_test2"; print "exp_name is $exp_name\n";




chrom_analysis("2L");
chrom_analysis("2R");
chrom_analysis("3L");
chrom_analysis("3R");
chrom_analysis("4");
chrom_analysis("X");

sub chrom_analysis{  ####don't forget to close bracket!
	
my $chrom = shift;


system("/gff/Targeted DamID/analyses/Perl/merge_replicate_data.pl", "$exp_name", "$chrom"); 

}