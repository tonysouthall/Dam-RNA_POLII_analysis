#!usr/bin/perl
#model POLII binding significance
use warnings;



print "\nEnter name for analysis\n\n";
$exp_name = <STDIN>;
chomp $exp_name;

print "\nEnter FDR threshold \(usually 0.01 - 1%\)\n\n";
$FDRthres = <STDIN>;
chomp $FDRthres;

print "\nEnter log2 ratio threshold \(usually 0.585 - 1.5 fold\)\n\n";
$ratiothres = <STDIN>;
chomp $ratiothres;




system("/gff/Targeted DamID/analyses/Perl_for_3_replicates_transcripts/make_just_genes_file.pl", "$exp_name");

system("/gff/Targeted DamID/analyses/Perl_for_3_replicates_transcripts/make_unique_gene_list.pl", "$exp_name");

system("/gff/Targeted DamID/analyses/Perl_for_3_replicates_transcripts/filter_gene_list.pl", "$exp_name", "$FDRthres", "$ratiothres");