#!usr/bin/perl
#make unique gene lists
use warnings;


#gives unique gene using values from the transcript with the lowest FDR

$name = $ARGV[0]; #print "exp_name is $name\n";
#$dir = $ARGV[1];

print"\nMaking unique gene lists\n";




open (INPUT, 'POLII_analysis_for_'."$name".'/Filtered_results/filtered_'."$name".'_results_1_percent_FDR_and_0.5_log_ratio_change_all_transcripts.txt')or die "\nCan't open filtered results data file!\n";

open (OUTPUT, '> POLII_analysis_for_'."$name".'/Filtered_results/Unique_gene_lists/filtered_unique_gene_results_for_'."$name".'__1_percent_FDR_and_0.5_log_ratio.txt');

print OUTPUT "Gene\tTranscript\tRatio\tFDR\n";

@results = <INPUT>; 
$resultsnum = @results;

$ln1 = 1;

while($ln1 < $resultsnum){
	my @col = split(/\t/,$results[$ln1]);
	push @array, \@col;
	$ln1 = $ln1 + 1;	    
	 		}


@sorted_array_1 = sort{$$a[0]cmp$$b[0]}@array;
$num = @sorted_array_1; #print "\nSorted array is $num big!\n";



$ln1 = 0;

while($ln1 < ($num - 1)){
		#$gene = $sorted_array_1[$ln1][4]; chomp $gene; 
		
	if($sorted_array_1[$ln1][0] eq $sorted_array_1[$ln1 + 1][0]){
		push (@miniarray, "$sorted_array_1[$ln1][0]\t$sorted_array_1[$ln1][1]\t$sorted_array_1[$ln1][2]\t$sorted_array_1[$ln1][3]");
		
	}else{
		push (@miniarray, "$sorted_array_1[$ln1][0]\t$sorted_array_1[$ln1][1]\t$sorted_array_1[$ln1][2]\t$sorted_array_1[$ln1][3]");
		$min_num = @miniarray; #print "\nsize of miniarray is $min_num";
		$ln2 = 0;
		while($ln2 < $min_num){
	my @minicol = split(/\t/,$miniarray[$ln2]); 
	push @AoA, \@minicol; #print "$AoA[0][1]";
	$ln2 = $ln2 + 1;	    
	 		}
	 		@mini_sorted_array = sort{$$b[2]<=>$$a[2]}@AoA; #$sortnum = @mini_sorted_array; #print "\nsize of mini sorted array is $sortnum";
	 		#@mini_sorted_array2 = sort{$$a[1]<=>$$b[1]}@mini_sorted_array;
	 		
	 		
	  			               	print OUTPUT "$mini_sorted_array[0][0]\t$mini_sorted_array[0][1]\t$mini_sorted_array[0][2]\t$mini_sorted_array[0][3]";
	  			               	#print OUTPUT2 "$mini_sorted_array[0][0]\t$mini_sorted_array[0][1]\t$mini_sorted_array[0][2]\t$mini_sorted_array[0][3]";
																		
					@miniarray = ();
					@mini_sorted_array = ();
					#@mini_sorted_array2 = ();
					@AoA = ();
				}
				$ln1 = $ln1 + 1;
			}	
	
	
					  	
	  		$lastgene = $sorted_array_1[$num - 1][0]; #chomp $lastgene;
	  		if($lastgene ne $sorted_array_1[$num - 2][0]){
	  			               
	  			              	
													print OUTPUT "$sorted_array_1[$num - 1][0]\t$sorted_array_1[$num - 1][1]\t$sorted_array_1[$num - 1][2]\t$sorted_array_1[$num - 1][3]";
													
												}	
												

close OUTPUT;
close INPUT;


# now the second filtered list......


open (INPUT2, 'POLII_analysis_for_'."$name".'/Filtered_results/filtered_'."$name".'_results_1_percent_FDR_and_0.3_log_ratio_change_all_transcripts.txt')or die "\nCan't open 0.3 log filtered results data file!\n";

open (OUTPUT2, '> POLII_analysis_for_'."$name".'/Filtered_results/Unique_gene_lists/filtered_unique_gene_results_for_'."$name".'__1_percent_FDR_and_0.3_log_ratio.txt');

print OUTPUT2 "Gene\tTranscript\tRatio\tFDR\n";

@results = <INPUT2>; 
$resultsnum = @results;

$ln1 = 1;

while($ln1 < $resultsnum){
	my @col = split(/\t/,$results[$ln1]);
	push @array, \@col;
	$ln1 = $ln1 + 1;	    
	 		}


@sorted_array_1 = sort{$$a[0]cmp$$b[0]}@array;
$num = @sorted_array_1; #print "\nSorted array is $num big!\n";



$ln1 = 0;

while($ln1 < ($num - 1)){
		#$gene = $sorted_array_1[$ln1][4]; chomp $gene; 
		
	if($sorted_array_1[$ln1][0] eq $sorted_array_1[$ln1 + 1][0]){
		push (@miniarray, "$sorted_array_1[$ln1][0]\t$sorted_array_1[$ln1][1]\t$sorted_array_1[$ln1][2]\t$sorted_array_1[$ln1][3]");
		
	}else{
		push (@miniarray, "$sorted_array_1[$ln1][0]\t$sorted_array_1[$ln1][1]\t$sorted_array_1[$ln1][2]\t$sorted_array_1[$ln1][3]");
		$min_num = @miniarray; #print "\nsize of miniarray is $min_num";
		$ln2 = 0;
		while($ln2 < $min_num){
	my @minicol = split(/\t/,$miniarray[$ln2]); 
	push @AoA, \@minicol; #print "$AoA[0][1]";
	$ln2 = $ln2 + 1;	    
	 		}
	 		@mini_sorted_array = sort{$$b[2]<=>$$a[2]}@AoA; #$sortnum = @mini_sorted_array; #print "\nsize of mini sorted array is $sortnum";
	 		#@mini_sorted_array2 = sort{$$a[1]<=>$$b[1]}@mini_sorted_array;
	 		
	 		
	  			               	print OUTPUT2 "$mini_sorted_array[0][0]\t$mini_sorted_array[0][1]\t$mini_sorted_array[0][2]\t$mini_sorted_array[0][3]";
	  			               	#print OUTPUT2 "$mini_sorted_array[0][0]\t$mini_sorted_array[0][1]\t$mini_sorted_array[0][2]\t$mini_sorted_array[0][3]";
																		
					@miniarray = ();
					@mini_sorted_array = ();
					#@mini_sorted_array2 = ();
					@AoA = ();
				}
				$ln1 = $ln1 + 1;
			}	
	
	
					  	
	  		$lastgene = $sorted_array_1[$num - 1][0]; #chomp $lastgene;
	  		if($lastgene ne $sorted_array_1[$num - 2][0]){
	  			               
	  			              	
													print OUTPUT2 "$sorted_array_1[$num - 1][0]\t$sorted_array_1[$num - 1][1]\t$sorted_array_1[$num - 1][2]\t$sorted_array_1[$num - 1][3]";
													
												}	
												

close OUTPUT2;
close INPUT2;

# now the third filtered list......


open (INPUT3, 'POLII_analysis_for_'."$name".'/Filtered_results/filtered_'."$name".'_results_1_percent_FDR_and_0.2_log_ratio_change_all_transcripts.txt')or die "\nCan't open filtered 0.2 log results data file!\n";

open (OUTPUT3, '> POLII_analysis_for_'."$name".'/Filtered_results/Unique_gene_lists/filtered_unique_gene_results_for_'."$name".'__1_percent_FDR_and_0.2_fold_ratio.txt');

print OUTPUT3 "Gene\tTranscript\tRatio\tFDR\n";

@results = <INPUT3>; 
$resultsnum = @results;

$ln1 = 1;

while($ln1 < $resultsnum){
	my @col = split(/\t/,$results[$ln1]);
	push @array, \@col;
	$ln1 = $ln1 + 1;	    
	 		}


@sorted_array_1 = sort{$$a[0]cmp$$b[0]}@array;
$num = @sorted_array_1; #print "\nSorted array is $num big!\n";



$ln1 = 0;

while($ln1 < ($num - 1)){
		#$gene = $sorted_array_1[$ln1][4]; chomp $gene; 
		
	if($sorted_array_1[$ln1][0] eq $sorted_array_1[$ln1 + 1][0]){
		push (@miniarray, "$sorted_array_1[$ln1][0]\t$sorted_array_1[$ln1][1]\t$sorted_array_1[$ln1][2]\t$sorted_array_1[$ln1][3]");
		
	}else{
		push (@miniarray, "$sorted_array_1[$ln1][0]\t$sorted_array_1[$ln1][1]\t$sorted_array_1[$ln1][2]\t$sorted_array_1[$ln1][3]");
		$min_num = @miniarray; #print "\nsize of miniarray is $min_num";
		$ln2 = 0;
		while($ln2 < $min_num){
	my @minicol = split(/\t/,$miniarray[$ln2]); 
	push @AoA, \@minicol; #print "$AoA[0][1]";
	$ln2 = $ln2 + 1;	    
	 		}
	 		@mini_sorted_array = sort{$$b[2]<=>$$a[2]}@AoA; #$sortnum = @mini_sorted_array; #print "\nsize of mini sorted array is $sortnum";
	 		#@mini_sorted_array2 = sort{$$a[1]<=>$$b[1]}@mini_sorted_array;
	 		
	 		
	  			               	print OUTPUT3 "$mini_sorted_array[0][0]\t$mini_sorted_array[0][1]\t$mini_sorted_array[0][2]\t$mini_sorted_array[0][3]";
	  			               	#print OUTPUT2 "$mini_sorted_array[0][0]\t$mini_sorted_array[0][1]\t$mini_sorted_array[0][2]\t$mini_sorted_array[0][3]";
																		
					@miniarray = ();
					@mini_sorted_array = ();
					#@mini_sorted_array2 = ();
					@AoA = ();
				}
				$ln1 = $ln1 + 1;
			}	
	
	
					  	
	  		$lastgene = $sorted_array_1[$num - 1][0]; #chomp $lastgene;
	  		if($lastgene ne $sorted_array_1[$num - 2][0]){
	  			               
	  			              	
													print OUTPUT3 "$sorted_array_1[$num - 1][0]\t$sorted_array_1[$num - 1][1]\t$sorted_array_1[$num - 1][2]\t$sorted_array_1[$num - 1][3]";
													
												}	
												

close OUTPUT3;
close INPUT3;

exit;