#!usr/bin/perl
#calculate distribution of POLII scores in randomised data set
use warnings;

$name = $ARGV[0]; #print "exp_name is $name\n";
$rep_no = $ARGV[1];  #print "replicate is $rep_no\n";
$chrom = $ARGV[2];  #print "chrom is $chrom\n";

#$name = "epith_test2"; print "exp_name is $name\n";
#$rep_no = "1";  print "replicate is $rep_no\n";
#$chrom = "2L";  print "chrom is $chrom\n";

print "\nAnalysing FDR distribution for $chrom replicate $rep_no\n";


open INPUT, 'POLII_analysis_for_'."$name".'/logfiles/chr'."$chrom".'_data_rep'."$rep_no".'.txt' or die "\ncan't open file!!";
@file = <INPUT>;
$num = @file;




$bp = 250;
while($bp < 2750){
if($chrom =~ m/4/){
	
if($bp == 250){$thres = 0.2; $max_thres = 0.75;}
if($bp == 500){$thres = 0.15; $max_thres = 0.75;}
if($bp == 750){$thres = 0.15; $max_thres = 0.7;}
if($bp == 1000){$thres = 0.1; $max_thres = 0.65;}
if($bp == 1250){$thres = 0.1; $max_thres = 0.6;}
if($bp == 1500){$thres = 0.05; $max_thres = 0.6;}
if($bp == 1750){$thres = 0.05; $max_thres = 0.5;}
if($bp == 2000){$thres = 0; $max_thres = 0.45;}
if($bp == 2250){$thres = 0; $max_thres = 0.4;}
if($bp == 2500){$thres = 0; $max_thres = 0.4;}	

}else{
	
if($bp == 250){$thres = 0.2; $max_thres = 0.75;}
if($bp == 500){$thres = 0.2; $max_thres = 0.75;}
if($bp == 750){$thres = 0.2; $max_thres = 0.75;}
if($bp == 1000){$thres = 0.15; $max_thres = 0.65;}
if($bp == 1250){$thres = 0.15; $max_thres = 0.65;}
if($bp == 1500){$thres = 0.1; $max_thres = 0.65;}
if($bp == 1750){$thres = 0.1; $max_thres = 0.6;}
if($bp == 2000){$thres = 0.1; $max_thres = 0.6;}
if($bp == 2250){$thres = 0.1; $max_thres = 0.55;}
if($bp == 2500){$thres = 0.1; $max_thres = 0.55;}

}

while($thres <= $max_thres){

$iter = 0;
$freq = 0;

while($iter < 10){

use List::Util 'shuffle';

@shuffled = shuffle(@file);

@shuf_ratios = ();

$ln = 0;
while($ln < $num){
	@col = split(/\t/,$file[$ln]); 
	@shufcol = split(/\t/,$shuffled[$ln]);
	push (@shuf_ratios, "$col[0]\t$shufcol[2]\n");
	$ln = $ln + 1;
}
@shuffled	= ();
	

$sec_iter = 0;

while($sec_iter < 1000){


	
	$totalscore = 0;
	$count = 0;
	
	$ln1 = int(rand($num - 200)); $start = $ln1;
	
	while($ln1 < $num){
		@col = split(/\t/,$shuf_ratios[$ln1]);
		@startcol = split(/\t/,$shuf_ratios[$start]);
		
		if($col[0] < ($startcol[0] + $bp)){
			$totalscore = $totalscore + $col[1]; #print "\ntotalscore is $totalscore";
			$count = $count + 1;
		}else{
			$averagescore = $totalscore / $count; #print "\nAveragescore is $averagescore";
			if($averagescore >= $thres){
				$freq = $freq + 1;
			}
					
			$ln1 = $num - 1;
		}
		$ln1 = $ln1 + 1;
	}
	
	$sec_iter = $sec_iter + 1;
}	
	
	$iter = $iter + 1;
}
$FDR = $freq / 10000;

			open LOG, '>> POLII_analysis_for_'."$name".'/logfiles/chr'."$chrom".'_data_rep'."$rep_no".'_random_data.txt';
			print LOG "chr$chrom\t$thres\t$bp\t$FDR\n"; #print "\nchr$chrom\t$thres\t$bp\t$FDR";
			close LOG;
			
			$thres = $thres + 0.05;
		}	
	
	$bp = $bp + 250; #print "\n$bp bp";
}



#print "\n $name analysis for chrom $chrom, rep $rep_no done!";

exit;
	
		
			