#!usr/bin/perl
#merge data
use warnings;

$name = $ARGV[0]; #print "exp_name is $name\n";
$chrom = $ARGV[1];  #print "chrom is $chrom\n";
$rep_num = $ARGV[2];

#$name = "epith_test2"; print "exp_name is $name\n";
#$chrom = "2L";  print "chrom is $chrom\n";

print "\nMerging replicate data for $chrom\n";



if($rep_num == 3){
	
open INPUT, 'POLII_analysis_for_'."$name".'/temp/chr'."$chrom".'_FDR_value_data_rep1.txt' or die "\ncan't open file!!";
@file1 = <INPUT>;
$num = @file1;

if($rep_num > 1){
open INPUT2, 'POLII_analysis_for_'."$name".'/temp/chr'."$chrom".'_FDR_value_data_rep2.txt' or die "\ncan't open file!!";
@file2 = <INPUT2>;}

if($rep_num > 2){
open INPUT3, 'POLII_analysis_for_'."$name".'/temp/chr'."$chrom".'_FDR_value_data_rep3.txt' or die "\ncan't open file!!";
@file3 = <INPUT3>;}	
	
	
	

$ln = 0;

	while($ln < $num){
		@col1 = split(/\t/,$file1[$ln]);
		@col2 = split(/\t/,$file2[$ln]);
		@col3 = split(/\t/,$file3[$ln]);
		
		push (@array, "$col1[3]");
		push (@array, "$col2[3]");
		push (@array, "$col3[3]");
		
		@sorted_array = sort {$b <=> $a} @array;
		$average_ratio = (($col1[2] + $col2[2] + $col3[2]) / 3);
		$average_ratio = sprintf("%.3f", $average_ratio);
		#$FDR = sprintf("%.4f", $sorted_array[0]);
		$FDR = $sorted_array[0];
		
		open LOG, '>> POLII_analysis_for_'."$name".'/temp/final_results_for_'."$name".'.txt';
		print LOG "$col1[1]\t$average_ratio\t$FDR";
		close LOG;
				
		@array = ();
		@sorted_array = ();
		
		$ln = $ln + 1;
	}
		
	close INPUT;
	close INPUT2;
	close INPUT3;
	
	}
	
	
if($rep_num == 2){
	
open INPUT, 'POLII_analysis_for_'."$name".'/temp/chr'."$chrom".'_FDR_value_data_rep1.txt' or die "\ncan't open file!!";
@file1 = <INPUT>;
$num = @file1;

if($rep_num > 1){
open INPUT2, 'POLII_analysis_for_'."$name".'/temp/chr'."$chrom".'_FDR_value_data_rep2.txt' or die "\ncan't open file!!";
@file2 = <INPUT2>;}

$ln = 0;

	while($ln < $num){
		@col1 = split(/\t/,$file1[$ln]);
		@col2 = split(/\t/,$file2[$ln]);
				
		push (@array, "$col1[3]");
		push (@array, "$col2[3]");
				
		@sorted_array = sort {$b <=> $a} @array;
		$average_ratio = (($col1[2] + $col2[2]) / 2);
		$average_ratio = sprintf("%.3f", $average_ratio);
		#$FDR = sprintf("%.4f", $sorted_array[0]);
		$FDR = $sorted_array[0];
		
		open LOG, '>> POLII_analysis_for_'."$name".'/temp/final_results_for_'."$name".'.txt';
		print LOG "$col1[1]\t$average_ratio\t$FDR";
		close LOG;
				
		@array = ();
		@sorted_array = ();
		
		$ln = $ln + 1;
	}
		
	close INPUT;
	close INPUT2;
		
	}	
	
	
if($rep_num == 1){
	
open INPUT, 'POLII_analysis_for_'."$name".'/temp/chr'."$chrom".'_FDR_value_data_rep1.txt' or die "\ncan't open file!!";
@file1 = <INPUT>;
$num = @file1;

$ln = 0;

	while($ln < $num){
		@col1 = split(/\t/,$file1[$ln]);
						
				
		@sorted_array = sort {$b <=> $a} @array;
		$ratio = $col1[2];
		$ratio = sprintf("%.3f", $ratio);
		$FDR = $col1[3];
		
		open LOG, '>> POLII_analysis_for_'."$name".'\temp\final_results_for_'."$name".'.txt';
		print LOG "$col1[1]\t$ratio\t$FDR";
		close LOG;
				
		@array = ();
		@sorted_array = ();
		
		$ln = $ln + 1;
	}
		
	close INPUT;
			
	}	
	

	
	#print "\nAll done!";
	
	exit;