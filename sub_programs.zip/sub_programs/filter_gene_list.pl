#!usr/bin/perl
#filter_results
use warnings;

$name = $ARGV[0]; #print "exp_name is $name\n";
#$dir = $ARGV[1];

#$FDRthres = $ARGV[1];  print "FDR threshold is $FDRthres\n";
#$ratiothres = $ARGV[2];  print "Ratio threshold is $ratiothres\n";

#$name = "Mikey_test_prog"; print "exp_name is $name\n";
#$FDRthres = "0.01";  print "FDR threshold is $FDRthres\n";
#$ratiothres = "0.585";  print "Ratio threshold is $ratiothres\n";



#mkdir "$dir".'POLII_analysis_for_'."$name".'/Filtered_results', 0755 or die "\nCan't make filtered results directory!\n";
open (OUTPUT, '> POLII_analysis_for_'."$name".'/Filtered_results/filtered_'."$name".'_results_1_percent_FDR_and_0.5_log_ratio_change_all_transcripts.txt');
open (OUTPUT2, '> POLII_analysis_for_'."$name".'/Filtered_results/filtered_'."$name".'_results_1_percent_FDR_and_0.3_log_ratio_change_all_transcripts.txt');
open (OUTPUT3, '> POLII_analysis_for_'."$name".'/Filtered_results/filtered_'."$name".'_results_1_percent_FDR_and_0.2_log_ratio_change_all_transcripts.txt');

open (INPUT, 'POLII_analysis_for_'."$name".'/final_results_for_'."$name".'_all_transcripts.txt')or die "\nCan't open final results data file!\n";

print OUTPUT "Gene\tTranscript\tRatio\tFDR\n";
print OUTPUT2 "Gene\tTranscript\tRatio\tFDR\n";
print OUTPUT3 "Gene\tTranscript\tRatio\tFDR\n";

@results = <INPUT>; 
$resultsnum = @results;

$ln1 = 1;

while($ln1 < $resultsnum){
	@col = split(/\t/,$results[$ln1]);
	$FDR = $col[3]; chomp $FDR; #print "FDR\n";
	$ratio = $col[2]; #print "$ratio\n";
	
	if(($FDR < 0.01) && ($ratio > 0.5)){print OUTPUT "$results[$ln1]";}
	if(($FDR < 0.01) && ($ratio > 0.3)){print OUTPUT2 "$results[$ln1]";}	
	if(($FDR < 0.01) && ($ratio > 0.2)){print OUTPUT3 "$results[$ln1]";}	
	
	$ln1 = $ln1 + 1;
}

#print "\nFiltered results file made\n";


close OUTPUT;
close OUTPUT2;
close OUTPUT3;

exit;