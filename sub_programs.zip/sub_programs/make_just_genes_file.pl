#!usr/bin/perl
#transcripts to just genes
use warnings;

$name = $ARGV[0]; #print "Oh yeah exp_name is $name\n";


print "\nMaking file with gene symbols\n";


open (OUTPUT, '> POLII_analysis_for_'."$name".'/final_results_for_'."$name".'_all_transcripts.txt');

open (INPUT, 'POLII_analysis_for_'."$name".'/temp/final_results_for_'."$name".'.txt')or die "\nCan't open final results data file!\n";

	print OUTPUT "Gene\tTranscript\tRatio\tFDR\n";
	

@results = <INPUT>; 
$resultsnum = @results;

$ln1 = 0;

while($ln1 < $resultsnum){
	@col = split(/\t/,$results[$ln1]);
	@col2 = split(/-R/,$col[0]);
	$gene = $col2[0];
	
	print OUTPUT "$gene\t$col[0]\t$col[1]\t$col[2]";
	#print OUTPUT2 "$gene\t$col[0]\t$col[1]\t$col[2]";
	
	$ln1 = $ln1 + 1;
	
}


exit;