#!usr/bin/perl
#peak_finding_with_FDR
use warnings;




print "\nEnter name of original POLII analysis\n\n";
$exp_name = <STDIN>;
chomp $exp_name;

mkdir 'c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\POLII_stall_analysis', 0755 or die "\nCan't make analysis directory!\n";

$thres = 1.585; #3-fold difference


$rep_no = 1;

while($rep_no < 4){

open (INPUT, 'c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\logfiles\chr2L_data_rep'."$rep_no".'.txt');
open (INPUT2, 'c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\logfiles\chr2R_data_rep'."$rep_no".'.txt');
open (INPUT3, 'c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\logfiles\chr3L_data_rep'."$rep_no".'.txt');
open (INPUT4, 'c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\logfiles\chr3R_data_rep'."$rep_no".'.txt');
open (INPUT5, 'c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\logfiles\chr4_data_rep'."$rep_no".'.txt');
open (INPUT6, 'c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\logfiles\chrX_data_rep'."$rep_no".'.txt');

@chr2L = <INPUT>; $num2L = @chr2L;
@chr2R = <INPUT2>; $num2R = @chr2R;
@chr3L = <INPUT3>; $num3L = @chr3L;
@chr3R = <INPUT4>; $num3R = @chr3R;
@chr4 = <INPUT5>; $num4 = @chr4;
@chrX = <INPUT6>; $numX= @chrX;

open (INPUT7, 'c:\gff\Targeted DamID\analyses\coords_for_POLII_stall_analysis.txt');
@stall_coord = <INPUT7>; $num_stall = @stall_coord;

####################### chr2L ########################
$ln = 1;
while($ln < $num_stall){
	@col = split(/\t/,$stall_coord[$ln]);
	if($col[0] =~ m/^chr2L$/){
		$ln2 = 0; 	$prom_score = 0;	$prom_probes = 1; $rest_gene_score = 0;	$rest_gene_probes = 1;
		while($ln2 < $num2L){
			@col2 = split(/\t/,$chr2L[$ln2]);
		if(($col2[0] >= $col[2]) && ($col2[0] <= $col[3])){$prom_score = $prom_score + $col2[1]; 	$prom_probes = $prom_probes + 1;}
		if((($col2[0] >= $col[4]) && ($col2[0] <= $col[5])) || (($col2[0] >= $col[5]) && ($col2[0] <= $col[4]))){$rest_gene_score = $rest_gene_score + $col2[1]; 	$rest_gene_probes = $rest_gene_probes + 1;}
		$ln2 = $ln2 + 1;
	}
	$average_prom_score = ($prom_score / $prom_probes); $average_prom_score = sprintf("%.4f", $average_prom_score);
	$average_rest_gene_score = ($rest_gene_score / $rest_gene_probes); $average_rest_gene_score = sprintf("%.4f", $average_rest_gene_score);  $diff = $average_prom_score - $average_rest_gene_score;
	if(($diff >= $thres) && ($average_rest_gene_score < 1) && ($average_prom_score > 1)  ){
open LOG, '>> c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\POLII_stall_analysis\POLII_stall_results_for_'."$exp_name".'_rep'."$rep_no".'.txt';
print LOG "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
close LOG;			print "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
}
}			
		$ln = $ln + 1;}
			
####################### chr2R ########################
$ln = 1;
while($ln < $num_stall){
	@col = split(/\t/,$stall_coord[$ln]);
	if($col[0] =~ m/^chr2R$/){
		$ln2 = 0; 	$prom_score = 0;	$prom_probes = 1; $rest_gene_score = 0;	$rest_gene_probes = 1;
		while($ln2 < $num2R){
			@col2 = split(/\t/,$chr2R[$ln2]);
		if(($col2[0] >= $col[2]) && ($col2[0] <= $col[3])){$prom_score = $prom_score + $col2[1]; 	$prom_probes = $prom_probes + 1;}
		if((($col2[0] >= $col[4]) && ($col2[0] <= $col[5])) || (($col2[0] >= $col[5]) && ($col2[0] <= $col[4]))){$rest_gene_score = $rest_gene_score + $col2[1]; 	$rest_gene_probes = $rest_gene_probes + 1;}
		$ln2 = $ln2 + 1;
	}
	$average_prom_score = ($prom_score / $prom_probes); $average_prom_score = sprintf("%.4f", $average_prom_score);
	$average_rest_gene_score = ($rest_gene_score / $rest_gene_probes); $average_rest_gene_score = sprintf("%.4f", $average_rest_gene_score);  $diff = $average_prom_score - $average_rest_gene_score;
	if(($diff >= $thres) && ($average_rest_gene_score < 1) && ($average_prom_score > 1)  ){
open LOG, '>> c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\POLII_stall_analysis\POLII_stall_results_for_'."$exp_name".'_rep'."$rep_no".'.txt';
print LOG "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
close LOG;			print "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
}
}			
		$ln = $ln + 1;}

####################### chr3L ########################
$ln = 1;
while($ln < $num_stall){
	@col = split(/\t/,$stall_coord[$ln]);
	if($col[0] =~ m/^chr3L$/){
		$ln2 = 0; 	$prom_score = 0;	$prom_probes = 1; $rest_gene_score = 0;	$rest_gene_probes = 1;
		while($ln2 < $num3L){
			@col2 = split(/\t/,$chr3L[$ln2]);
		if(($col2[0] >= $col[2]) && ($col2[0] <= $col[3])){$prom_score = $prom_score + $col2[1]; 	$prom_probes = $prom_probes + 1;}
		if((($col2[0] >= $col[4]) && ($col2[0] <= $col[5])) || (($col2[0] >= $col[5]) && ($col2[0] <= $col[4]))){$rest_gene_score = $rest_gene_score + $col2[1]; 	$rest_gene_probes = $rest_gene_probes + 1;}
		$ln2 = $ln2 + 1;
	}
	$average_prom_score = ($prom_score / $prom_probes); $average_prom_score = sprintf("%.4f", $average_prom_score);
	$average_rest_gene_score = ($rest_gene_score / $rest_gene_probes); $average_rest_gene_score = sprintf("%.4f", $average_rest_gene_score);  $diff = $average_prom_score - $average_rest_gene_score;
#open LOG, '>> c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\POLII_stall_analysis\POLII_stall_full_results_for_'."$exp_name".'.txt';
#print LOG "$col[0]\t$col[1]\t$prom_probes\t$rest_gene_probes\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
#close LOG;	
	if(($diff >= $thres) && ($average_rest_gene_score < 1) && ($average_prom_score > 1)  ){
open LOG, '>> c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\POLII_stall_analysis\POLII_stall_results_for_'."$exp_name".'_rep'."$rep_no".'.txt';
print LOG "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
close LOG;			print "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
}
}			
		$ln = $ln + 1;}

####################### chr3R ########################
$ln = 1;
while($ln < $num_stall){
	@col = split(/\t/,$stall_coord[$ln]);
	if($col[0] =~ m/^chr3R$/){
		$ln2 = 0; 	$prom_score = 0;	$prom_probes = 1; $rest_gene_score = 0;	$rest_gene_probes = 1;
		while($ln2 < $num3R){
			@col2 = split(/\t/,$chr3R[$ln2]);
		if(($col2[0] >= $col[2]) && ($col2[0] <= $col[3])){$prom_score = $prom_score + $col2[1]; 	$prom_probes = $prom_probes + 1;}
		if((($col2[0] >= $col[4]) && ($col2[0] <= $col[5])) || (($col2[0] >= $col[5]) && ($col2[0] <= $col[4]))){$rest_gene_score = $rest_gene_score + $col2[1]; 	$rest_gene_probes = $rest_gene_probes + 1;}
		$ln2 = $ln2 + 1;
	}
	$average_prom_score = ($prom_score / $prom_probes); $average_prom_score = sprintf("%.4f", $average_prom_score);
	$average_rest_gene_score = ($rest_gene_score / $rest_gene_probes); $average_rest_gene_score = sprintf("%.4f", $average_rest_gene_score);  $diff = $average_prom_score - $average_rest_gene_score;
	if(($diff >= $thres) && ($average_rest_gene_score < 1) && ($average_prom_score > 1)  ){
open LOG, '>> c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\POLII_stall_analysis\POLII_stall_results_for_'."$exp_name".'_rep'."$rep_no".'.txt';
print LOG "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
close LOG;			print "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
}
}			
		$ln = $ln + 1;}

####################### chr4 ########################
$ln = 1;
while($ln < $num_stall){
	@col = split(/\t/,$stall_coord[$ln]);
	if($col[0] =~ m/^chr4$/){
		$ln2 = 0; 	$prom_score = 0;	$prom_probes = 1; $rest_gene_score = 0;	$rest_gene_probes = 1;
		while($ln2 < $num4){
			@col2 = split(/\t/,$chr4[$ln2]);
		if(($col2[0] >= $col[2]) && ($col2[0] <= $col[3])){$prom_score = $prom_score + $col2[1]; 	$prom_probes = $prom_probes + 1;}
		if((($col2[0] >= $col[4]) && ($col2[0] <= $col[5])) || (($col2[0] >= $col[5]) && ($col2[0] <= $col[4]))){$rest_gene_score = $rest_gene_score + $col2[1]; 	$rest_gene_probes = $rest_gene_probes + 1;}
		$ln2 = $ln2 + 1;
	}
	$average_prom_score = ($prom_score / $prom_probes); $average_prom_score = sprintf("%.4f", $average_prom_score);
	$average_rest_gene_score = ($rest_gene_score / $rest_gene_probes); $average_rest_gene_score = sprintf("%.4f", $average_rest_gene_score);  $diff = $average_prom_score - $average_rest_gene_score;
	if(($diff >= $thres) && ($average_rest_gene_score < 1) && ($average_prom_score > 1)  ){
open LOG, '>> c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\POLII_stall_analysis\POLII_stall_results_for_'."$exp_name".'_rep'."$rep_no".'.txt';
print LOG "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
close LOG;			print "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
}
}			
		$ln = $ln + 1;}

####################### chrX ########################
$ln = 1;
while($ln < $num_stall){
	@col = split(/\t/,$stall_coord[$ln]);
	if($col[0] =~ m/^chrX$/){
		$ln2 = 0; 	$prom_score = 0;	$prom_probes = 1; $rest_gene_score = 0;	$rest_gene_probes = 1;
		while($ln2 < $numX){
			@col2 = split(/\t/,$chrX[$ln2]);
		if(($col2[0] >= $col[2]) && ($col2[0] <= $col[3])){$prom_score = $prom_score + $col2[1]; 	$prom_probes = $prom_probes + 1;}
		if((($col2[0] >= $col[4]) && ($col2[0] <= $col[5])) || (($col2[0] >= $col[5]) && ($col2[0] <= $col[4]))){$rest_gene_score = $rest_gene_score + $col2[1]; 	$rest_gene_probes = $rest_gene_probes + 1;}
		$ln2 = $ln2 + 1;
	}
	$average_prom_score = ($prom_score / $prom_probes); $average_prom_score = sprintf("%.4f", $average_prom_score);
	$average_rest_gene_score = ($rest_gene_score / $rest_gene_probes); $average_rest_gene_score = sprintf("%.4f", $average_rest_gene_score);  $diff = $average_prom_score - $average_rest_gene_score;
	if(($diff >= $thres) && ($average_rest_gene_score < 1) && ($average_prom_score > 1)  ){
open LOG, '>> c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$exp_name".'\POLII_stall_analysis\POLII_stall_results_for_'."$exp_name".'_rep'."$rep_no".'.txt';
print LOG "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
close LOG;			print "$col[0]\t$col[1]\t$average_prom_score\t$average_rest_gene_score\t$diff\n";
}
}			
		$ln = $ln + 1;}

close INPUT;
close INPUT2;
close INPUT3;
close INPUT4;
close INPUT5;
close INPUT6;

$rep_no = $rep_no + 1;
}