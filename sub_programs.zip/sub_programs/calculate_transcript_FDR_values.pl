#!usr/bin/perl
#calculate P-value
use warnings;

$name = $ARGV[0]; #print "exp_name is $name\n";
$rep_no = $ARGV[1];  #print "replicate is $rep_no\n";
$chrom = $ARGV[2];  #print "chrom is $chrom\n";

#$name = "epith_test2"; print "exp_name is $name\n";
#$rep_no = "1";  print "replicate is $rep_no\n";
#$chrom = "2L";  print "chrom is $chrom\n";

print "\nCalculating transcript FDR values for $chrom replicate $rep_no\n";



open INPUT, 'POLII_analysis_for_'."$name".'/temp/results_for_'."$name".'_chrom'."$chrom".'_rep'."$rep_no".'.txt' or die "\ncan't open file!!";
@file = <INPUT>;
$num = @file;

open INPUT2, 'POLII_analysis_for_'."$name".'/logfiles/chr'."$chrom".'_data_rep'."$rep_no".'_variables.txt';
@variables = <INPUT2>;
$var_num = @variables;

open INPUT3, 'POLII_analysis_for_'."$name".'/logfiles/rep'."$rep_no".'_linear_variables.txt';
@lin_var = <INPUT3>;
$lin_var_num = @lin_var;

open (OUTPUT, '> POLII_analysis_for_'."$name".'/temp/chr'."$chrom".'_FDR_value_data_rep'."$rep_no".'.txt');


##################################
$ln = 0;

while($ln < $lin_var_num){
	@col = split(/\t/,$lin_var[$ln]); 
	if($col[0] =~ m/$chrom/){$lin_varA = $col[1]; $lin_varB = $col[2];}
	$ln = $ln + 1;
}

close INPUT3;
@lin_var = ();

####################################

$ln = 0;
$total_varA = 0;

while($ln < $var_num){
	@col = split(/\t/,$variables[$ln]); 
	$total_varA = $total_varA + $col[2];
	$ln = $ln + 1;
}

$varA = $total_varA / $var_num;

close INPUT2;
@variables = ();

##############################	

$ln = 0;		

while($ln < $num){
	@col = split(/\t/,$file[$ln]); 
	$gene = $col[0];
	$ratio = $col[1];
	$gene_size = $col[2];
	$varB = ((($lin_varA * $gene_size) + $lin_varB));
	
	$P = $varA * exp(-$varB * $ratio); #$P = sprintf("%.3f", $P);
	
	print OUTPUT "$chrom\t$gene\t$ratio\t$P\n";	
	
	$ln = $ln + 1;
}

#print "\nP-values calculated for chrom $chrom rep $rep_no!";

close INPUT;
close OUTPUT;

exit;	