#!usr/bin/perl
#POLII_score_calculator.pl
use warnings;


$name = $ARGV[0]; #print "exp_name is $name\n";
$path = $ARGV[1];  #print "path is $path\n";
$rep_no = $ARGV[2];  #print "replicate is $rep_no\n";

print "\nAnalysing real data for replicate $rep_no\n";


#mkdir 'c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$name", 0755 or die "\nCan't make analysis directory!\n"; #Comment this line after testing script
#mkdir 'c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$name".'\logfiles', 0755 or die "\nCan't make analysis directory!\n"; #Comment this line after testing script

##########  first need to split file and remove unwanted info #################


open (OUTPUT, '> POLII_analysis_for_'."$name".'/logfiles/chr2L_data_rep'."$rep_no".'.txt');
open (OUTPUT2, '> POLII_analysis_for_'."$name".'/logfiles/chr2R_data_rep'."$rep_no".'.txt');
open (OUTPUT3, '> POLII_analysis_for_'."$name".'/logfiles/chr3L_data_rep'."$rep_no".'.txt');
open (OUTPUT4, '> POLII_analysis_for_'."$name".'/logfiles/chr3R_data_rep'."$rep_no".'.txt');
open (OUTPUT5, '> POLII_analysis_for_'."$name".'/logfiles/chr4_data_rep'."$rep_no".'.txt');
open (OUTPUT6, '> POLII_analysis_for_'."$name".'/logfiles/chrX_data_rep'."$rep_no".'.txt');


open (INPUT, "$path") or die "\nCan't open gff file!\n";
@file = <INPUT>;
$num = @file;



$ln1 = 0; #Set $ln1=0 for gff files without headers in the two first lines, $ln1=2 for files with headers in the two first lines.
while($ln1 < $num){       
	@col = split(/\t/,$file[$ln1]); 
	$value = $col[5]; $value = sprintf("%.3f", $value);

	#####put coord and ratio into files for anova test later################
	if($col[0] =~ m/^chr2L$/){push (@chr2L, "$col[3]\t$col[4]\t$value");}				
	if($col[0] =~ m/^chr2R$/){push (@chr2R, "$col[3]\t$col[4]\t$value");}
	if($col[0] =~ m/^chr3L$/){push (@chr3L, "$col[3]\t$col[4]\t$value");}
	if($col[0] =~ m/^chr3R$/){push (@chr3R, "$col[3]\t$col[4]\t$value");}
	if($col[0] =~ m/^chr4$/){push (@chr4, "$col[3]\t$col[4]\t$value");}
	if($col[0] =~ m/^chrX$/){push (@chrX, "$col[3]\t$col[4]\t$value");}
	##########################################################################

	$ln1 = $ln1 + 1;   
}
		
close INPUT;
@file = ();
		
#print "\nFile split and data extracted - now to sort by coordinate\n\n";

$num = @chr2L; 
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr2L[$ln]); 	push @AoA, \@col; $ln = $ln + 1;} #print "\n$AoA[0][0]\t$AoA[0][1]\n";
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT; 	@chr2L = ();  @AoA = (); @sorted_array = ();
		
$num = @chr2R;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr2R[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT2 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT2; 	@chr2R = ();  @AoA = (); @sorted_array = ();
		
$num = @chr3L;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr3L[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT3 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT3; 	@chr3L = ();  @AoA = (); @sorted_array = ();			

$num = @chr3R;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr3R[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT4 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT4; 	@chr3R = ();  @AoA = (); @sorted_array = ();

$num = @chr4;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr4[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT5 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT5; 	@chr4 = ();  @AoA = (); @sorted_array = ();

$num = @chrX;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chrX[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT6 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT6; 	@chrX = ();  @AoA = (); @sorted_array = ();



#############  now to calculate POLII average ratio change for each gene ##################

POLII_analysis("2L");
POLII_analysis("2R");
POLII_analysis("3L");
POLII_analysis("3R");
POLII_analysis("4");
POLII_analysis("X");

sub POLII_analysis{

	my $chrom = shift;

	open (INPUT1, 'transcript_info/dm_miRNA_ext_plus_ncRNAs_r6.11_chr'."$chrom".'_transcripts.txt') or die "\nCan't open gene file!\n";
	@gene_file = <INPUT1>; #print "\nchr$chrom genes file opened\n";

	open (INPUT2, 'POLII_analysis_for_'."$name".'/logfiles/chr'."$chrom".'_data_rep'."$rep_no".'.txt')or die "\nCan't open data file!\n";
	@data_file = <INPUT2>; #print "\nchr$chrom data file opened\n";
	
	open OUTPUT7, '> POLII_analysis_for_'."$name".'/temp/results_for_'."$name".'_chrom'."$chrom".'_rep'."$rep_no".'.txt';
	
	$num = @gene_file;
	$num2 = @data_file;
	$ln1 = 0;

	while($ln1 < $num){
		@col = split(/\t/,$gene_file[$ln1]);
		if(($col[1] eq "join") || ($col[2] eq "join")){$ln1 = $ln1 + 1;}else{
		$gene = $col[4];
		chomp $gene;
		$gene_size = $col[2] - $col[1];
	
		#print "\nLooking for values for gene $col[4]";
	
		$score = 0;
		$no_probes = 0;
	
		$ln2 = 0;
	
		while($ln2 < $num2){
			@data_col = split(/\t/,$data_file[$ln2]);
			if((($data_col[0] >= $col[1]) && ($data_col[0] <= $col[2])) || (($data_col[1] >= $col[1]) && ($data_col[1] <= $col[2]))){
				#print "\nData point found!";
				#open LOG, '>> c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$name".'\full_results_for_'."$name".'_rep'."$rep_no".'_all_transcripts.txt';
				#print LOG "$chrom\t$gene\t$data_col[1]";
				#close LOG;
				$score = $score + $data_col[2]; 
				$no_probes = $no_probes + 1;
			}
			#if($ln2 > $col[2]){$ln2 = $num2 - 2;}
			$ln2 = $ln2 + 1;
		}
	
		#print "\n$score\n";
		if ($no_probes > 0){
			$average_score = ($score / $no_probes);
			$average_score = sprintf("%.4f", $average_score);

			#open LOG, '>> c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$name".'\temp\results_for_'."$name".'_chrom'."$chrom".'_rep'."$rep_no".'.txt';
			print OUTPUT7 "$gene\t$average_score\t$gene_size\n";
			#close LOG;
			#print "\n$gene\t$average_score\t$gene_size\n";
		}
		$ln2 = $num2;
	}
		$ln1 = $ln1 + 1;
	}
	close INPUT1;
	close INPUT2;
	#close OUTPUT;
	close OUTPUT7;
	@gene_file = ();
	@data_file = ();	
}
	
#print "\nAll done!\n";

exit;