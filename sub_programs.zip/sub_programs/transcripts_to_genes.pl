#!usr/bin/perl
#transcripts to just genes
use warnings;


#$name = $ARGV[0]; print "exp_name is $name\n";

$name = "NB_POL_2reps_transcripts";

print "\n$name\n";


open (OUTPUT, '> c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$name".'\final_results_for_'."$name".'_just_genes.txt');

open (INPUT, 'c:\gff\Targeted DamID\analyses\POLII_analysis_for_'."$name".'\final_results_for_'."$name".'.txt')or die "\nCan't open final results data file!\n";


@data_file = <INPUT>;
$num = @data_file;

$ln1 = 0;

while($ln1 < $num){
	@col = split(/\t/,$data_file[$ln1]);
	$transcript = $col[0];
	
	@col2 = split(/-R\D/,$transcript);
	$gene = $col2[0];
	
	print OUTPUT "$gene\t$data_file[$ln1]";
	
	$ln1 = $ln1 + 1;
}

print "\nFile made with just gene names\n";

	