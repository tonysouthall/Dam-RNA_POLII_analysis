#!usr/bin/perl
#ratio_normalise_and_average
use warnings;


print "\nMaking average file\n";

$exp_name = $ARGV[0]; #print"$exp_name\n";
$paths = $ARGV[1];  #print "\nFiles for processing are: $paths\n";
$rep_num = $ARGV[2]; #print "\nNumber of replicates is $rep_num\n";

if($rep_num > 0){@col = split(/\t/,$paths); $path1 = $col[0]; chomp $path1;} #print "\nPath1 is $path1\n";
if($rep_num > 1){@col = split(/\t/,$paths); $path2 = $col[1]; chomp $path2;} #print "\nPath2 is $path2\n";
if($rep_num > 2){@col = split(/\t/,$paths); $path3 = $col[2]; chomp $path3;} #print "\nPath3 is $path3\n";


#open (OUTPUT13, '> POLII_analysis_for_'."$exp_name".'\processed_'."$exp_name".'_average.gff');

open (INPUT, "$path1") or die "\nCan't open first file\n";           #opens file using the path information
@firstfile = <INPUT>;             #assigns the file data to an array
$num = @firstfile;

@col = split(/\t/,$firstfile[1]); $colnum = @col;
if($colnum == 9){$ln1 = 0;}  #if a gff file, start from the first line
if($colnum == 4){$ln1 = 1;}  #if a bedgraph file, start from the second line

while($ln1 < $num){       
	@col = split(/\t/,$firstfile[$ln1]);
	$colnum = @col; 
	if($colnum == 9){$GATC_start = $col[3]; $GATC_end = $col[4]; $ratio = $col[5]; open (OUTPUT13, '> POLII_analysis_for_'."$exp_name".'\processed_'."$exp_name".'_average.gff'); $file_type = "gff";}  #if a gff file
	if($colnum == 4){$GATC_start = $col[1]; $GATC_end = $col[2]; $ratio = $col[3];open (OUTPUT13, '> POLII_analysis_for_'."$exp_name".'\processed_'."$exp_name".'_average.bedgraph'); $file_type = "bedgraph";
																					print OUTPUT13 'track type=bedGraph name='."$exp_name".' description='."$exp_name\n" or die "Can't print!";}    #if a bedgraph file
	
		
push (@ratio1, $ratio);  

$ln1 = $ln1 + 1;   
}

##########################################################################
if($rep_num > 1){

open (INPUT, "$path2");
@secondfile = <INPUT>;
$num = @secondfile;


@col = split(/\t/,$secondfile[1]); $colnum = @col; 
if($colnum == 9){$ln1 = 0;}  #if a gff file, start from the first line
if($colnum == 4){$ln1 = 1;}  #if a bedgraph file, start from the second line

$state = 0;

while($ln1 < $num){
	@col = split(/\t/,$secondfile[$ln1]);
	
	if($col[0] =~m/chr/){$chrom = $col[0];}else{$chrom = 'chr'."$col[0]";}
	
	$colnum = @col; 
	if($colnum == 9){$GATC_start = $col[3]; $GATC_end = $col[4]; $ratio2 = $col[5];}
	if($colnum == 4){$GATC_start = $col[1]; $GATC_end = $col[2]; $ratio2 = $col[3];}
	



if($rep_num == 3){push (@ratio2, $ratio2);}

	
if($rep_num == 2){		
$average = ( ($ratio1[$state] + $ratio2) / 2); if($average ne 0){$average = sprintf("%.3f", $average);}  #averages the values and rounds up values to a certain decimal point

			if($file_type eq "gff"){print OUTPUT13 "$chrom\t.\t$exp_name\t$GATC_start\t$GATC_end\t$average\t.\t.\t$col[8]";}    #writes value and other details to the file
			if($file_type eq "bedgraph"){print OUTPUT13 "$chrom\t$GATC_start\t$GATC_end\t$average"; } 
				}		
$state = $state + 1;
$ln1 = $ln1 + 1;   
}
}

######################################

if($rep_num > 2){

open (INPUT, "$path3");
@thirdfile = <INPUT>;

$num = @thirdfile;

@col = split(/\t/,$thirdfile[1]); $colnum = @col; 
if($colnum == 9){$ln1 = 0;}  #if a gff file, start from the first line
if($colnum == 4){$ln1 = 1;}  #if a bedgraph file, start from the second line

$state = 0;

while($ln1 < $num){
	@col = split(/\t/,$thirdfile[$ln1]);
	
if($col[0] =~m/chr/){$chrom = $col[0];}else{$chrom = 'chr'."$col[0]";}
	
	$colnum = @col; 
	if($colnum == 9){$GATC_start = $col[3]; $GATC_end = $col[4]; $ratio3 = $col[5];}
	if($colnum == 4){$GATC_start = $col[1]; $GATC_end = $col[2]; $ratio3 = $col[3];}
	
	
	
if($rep_num == 3){		
$average = ( ($ratio1[$state] + $ratio2[$state] + $ratio3) / 3); if($average ne 0){$average = sprintf("%.3f", $average);}  #averages the values and rounds up values to a certain decimal point

			if($file_type eq "gff"){print OUTPUT13 "$chrom\t.\t$exp_name\t$col[3]\t$col[4]\t$average\t.\t.\t$col[8]";}    #writes value and other details to the file
			if($file_type eq "bedgraph"){print OUTPUT13 "$chrom\t$GATC_start\t$GATC_end\t$average\n";} 
				}		
$state = $state + 1;



$ln1 = $ln1 + 1;   
}



#@thirdfile = ();
@ratio1 = ();


if($rep_num == 3){close OUTPUT13; #print "\nAverage file made\n";}

}


}




